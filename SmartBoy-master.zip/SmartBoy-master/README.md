# This is A My Command 




* pkg update

* pkg upgrade

* pkg install python

* pkg install python2

* pip2 install requests mechanize

* pkg install git

* git clone http://github.com/SmartBoyEasin/SmartBoy

* cd SmartBoy

* python2 SmartBoy.py
